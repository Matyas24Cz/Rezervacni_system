﻿
#include "Rezervacni_system_multikina.h"

using namespace std;


#include <string.h>
#include <stdio.h>

#pragma once
char sedadlo[50] = "";
char smer[99];


void sal(int cislo) {



    int i;

    for (i = 0; i < 50; i++) {


        if ((i - 1) % 10 == 0) {

            printf("[%c]\n", sedadlo[i]);

        }

        else

            printf("[%c]", sedadlo[i]);



    }



}

void zapis(int cislo, const char* smer) {

    int i;


    FILE* file;

    const char* filename = smer;


    file = fopen(filename, "w");


    for (i = 0; i < 50; i++) {


        if (i == (cislo - 1)) {

            fprintf(file, "x");

        }



        else {

            fprintf(file, "%c", sedadlo[i]);
        }

    }



    fclose(file);



}



int main() {
    int i;
    int cislo;
    int film = 0;
    int cas = 0;
    int casfilm;
    char heslo[6];
    int zrus = 0;
    int rada = 1;
    while (zrus < 1 || zrus > 2) {
        printf("Chcete:\n1 - Vybrat film\n2 - Zrusit rezervaci \n");
        scanf("%d", &zrus);
        if (zrus < 1 || zrus > 2) {
            printf("\nVyberte z moznosti 1 nebo 2!\n");
        }
    }
    switch (zrus) {
    case 1:
        while (film < 1 || film > 3) {
            printf("\nVyberte film:\n\n1 - Uni Furries\n2 - The Quantum Banana Rodeo\n3 - Invasion of the Disco Penguins\n");
            scanf("%d", &film);
            if (film < 1 || film > 3) {
                printf("\nVyberte z moznosti 1, 2 nebo 3!");
            }
        }
        while ((cas != 13) && (cas != 15) && (cas != 17)) {
            printf("Cas projekce:\n13 - 13:00\n15 - 15:00\n17 - 17:00\n");
            scanf("%d", &cas);
            if ((cas != 13) && (cas != 15) && (cas != 17)) {
                printf("\nVyberte z moznosti 13, 15 nebo 17!\n");
            }
        }
        casfilm = film * cas;
        break;
    case 2:
        printf("\nZadejte rezervacni kod: ");
        scanf("%s", &heslo);
        film = heslo[0] - '0';
        cas = (heslo[1] - '0') * 10 + (heslo[2] - '0');
        casfilm = film * cas;
        cislo = (heslo[3] - '0') * 10 + (heslo[4] - '0');
        break;
    }





    switch (casfilm) {
    case 13:
        strcpy(smer, "../../../KINOSAL/film_1_cas_13.txt");
        strcpy(heslo, "113");

        break;
    case 26:
        strcpy(smer, "../../../KINOSAL/film_2_cas_13.txt");
        strcpy(heslo, "213");
        break;
    case 39:
        strcpy(smer, "../../../KINOSAL/film_3_cas_13.txt");
        strcpy(heslo, "313");
        break;
    case 15:
        strcpy(smer, "../../../KINOSAL/film_1_cas_15.txt");
        strcpy(heslo, "115");
        break;
    case 30:
        strcpy(smer, "../../../KINOSAL/film_2_cas_15.txt");
        strcpy(heslo, "215");
        break;
    case 45:
        strcpy(smer, "../../../KINOSAL/film_3_cas_15.txt");
        strcpy(heslo, "315");
        break;
    case 17:
        strcpy(smer, "../../../KINOSAL/film_1_cas_17.txt");
        strcpy(heslo, "117");
        break;
    case 34:
        strcpy(smer, "../../../KINOSAL/film_2_cas_17.txt");
        strcpy(heslo, "217");
        break;
    case 51:
        strcpy(smer, "../../../KINOSAL/film_3_cas_17.txt");
        strcpy(heslo, "317");
        break;

    }


    FILE* file;

    const char* filename = smer;






    file = fopen(filename, "r");


    for (i = 0; i < 50; i++) {

        fscanf(file, "%c", &sedadlo[i]);
    }


    fclose(file);



    if (zrus == 1) {










        printf("    1  2  3  4  5  6  7  8  9  10");

        for (i = 0; i < 50; i++) {
            if ((i) % 10 == 0) {

                printf("\n %d [%c]", rada, sedadlo[i]);
                rada = rada + 1;

            }

            else

                printf("[%c]", sedadlo[i]);

        }

        

        char x[3];
        int cislox;
        int cislot;
        char y;
        int obsazeno = 0;
        while (obsazeno == 0) {

            printf("\n x - Obsazene sedadlo o - Volne sedadlo ");
            printf("\n\nZvolte sedadlo (1-10): ");
            scanf(" %2s", &x[0]);
            cislox = 0;
            for (int i = 0; x[i] != '\0'; ++i) {
                cislox = cislox * 10 + (x[i] - '0');
            }
            printf("V rade (1-5): ");
            scanf(" %c", &y);
            if (cislox % 10 == 0) {
                cislot = cislox * (y - '0');

                if ((cislot % 10) == 0) {

                    cislo = cislot;
                }
            }
            else {
                cislo = (((y - '0') - 1) * 10) + (cislox);
            }




            if (sedadlo[cislo - 1] == 'x') {

                printf("\nSedadlo je jiz obsazene\n");

            }
            else if (cislo < 10) {
                printf("\nVas kod je: %s0%d\n", heslo, cislo);
                obsazeno = 1;
            }

            else {
                printf("\nVas kod je: %s%d\n", heslo, cislo);
                obsazeno = 1;
            }

        }
        zapis(cislo, smer);
        
    }

    else if (zrus == 2) {

        FILE* file;
        const char* filename = smer;
        


        file = fopen(filename, "w");

        for (i = 0; i < 50; i++) {

            if (i == (cislo - 1)) {

                fprintf(file, "o");

            }



            else {

                fprintf(file, "%c", sedadlo[i]);
            }

        }


        fclose(file);




        printf("Rezervace uspesne zrusena");
    }




    return 0;
}
